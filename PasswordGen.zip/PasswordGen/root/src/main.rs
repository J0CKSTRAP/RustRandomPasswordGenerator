use rand::Rng;
use std::io::{self, Write};
use base64;

fn generate_password(num_digits: usize) -> String {
    let mut rng = rand::thread_rng();
    let password: String = (0..num_digits)
        .map(|_| rng.gen_range(0..=9).to_string())
        .collect();
    password
}

fn main() {
    let mut input = String::new();
    println!("Rusty Password Generator");

    print!("How many digits do you want in your password? ");
    io::stdout().flush().unwrap();
    io::stdin().read_line(&mut input).unwrap();

    let num_digits: usize = match input.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Invalid input. Please enter a valid number.");
            return;
        }
    };

    let password = generate_password(num_digits);

    

    // Base64 Encoding
    let encoded_password = base64::encode(&password);
    println!("Generated Password: {}", encoded_password);

    println!("Press Enter to exit...");
    io::stdin().read_line(&mut input).unwrap();
}